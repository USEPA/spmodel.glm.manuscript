skip_on_cran()
skip_if_not(
  identical(Sys.getenv("SPMODEL_RUN_EXTRAS"), "true"),
  "set Sys.setenv(SPMODEL_RUN_EXTRAS = 'true') before devtools::test() to run the extras suite"
)

#### local check
load(file = system.file("extdata", "exdata.rda", package = "spmodel"))
load(file = system.file("extdata", "exdata_poly.rda", package = "spmodel"))
load(file = system.file("extdata", "exdata_Mpoly.rda", package = "spmodel"))
load(file = system.file("extdata", "exdata_Upoly.rda", package = "spmodel"))

################################
########### row standardized
################################

test_that("the model runs for connected sites", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, estmethod = "ml"), NA)

  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, estmethod = "ml"), NA)
})

test_that("the model runs for connected sites given W", {
  spcov_type <- "car"
  W <- 1 * Matrix::Matrix(sf::st_intersects(exdata_poly, sparse = FALSE), sparse = TRUE)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W, estmethod = "ml"), NA)
})

test_that("the model runs for connected sites (partition group)", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group, estmethod = "ml"), NA)
})

test_that("the model runs for connected sites (random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  randcov_initial_val <- randcov_initial(group = 1, known = "group")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, randcov_initial = randcov_initial_val), NA)

  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, randcov_initial = randcov_initial_val, estmethod = "ml"), NA)

  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, estmethod = "ml"), NA)

  randcov_initial_val <- randcov_initial(group = 1, known = "group")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, randcov_initial = randcov_initial_val), NA)

  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, randcov_initial = randcov_initial_val, estmethod = "ml"), NA)
  })
})

test_that("the model runs for connected sites (partition and random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  })
})

test_that("the model runs for unconnected sites", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, estmethod = "ml"), NA)
  })
})

test_that("the model runs for unconnected sites (partition group)", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group, estmethod = "ml"), NA)
})

test_that("the model runs for unconnected sites (random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, estmethod = "ml"), NA)
  })
})

test_that("the model runs for unconnected sites (partition and random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  })
})

test_that("the model runs for missing sites", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, estmethod = "ml"), NA)
})

test_that("the model runs for missing sites (partition group)", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, partition_factor = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, partition_factor = ~group, estmethod = "ml"), NA)
})

test_that("the model runs for missing sites (random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, random = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, random = ~group, estmethod = "ml"), NA)
  })
})

test_that("the model runs for connected sites (partition and random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, partition_factor = ~group), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.5, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, estmethod = "ml"), NA)
  })
})

################################
########### row unstandardized
################################

test_that("the model runs for connected sites", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("the model runs for connected sites given W", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  W <- 1 * Matrix::Matrix(sf::st_intersects(exdata_poly, sparse = FALSE), sparse = TRUE)
  Wp <- W / rowSums(W)
  M <- 1 / rowSums(W)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = Wp, row_st = FALSE, M = M), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W, row_st = FALSE, estmethod = "ml"), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = Wp, row_st = FALSE, M = M, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = Wp, row_st = FALSE, M = M), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W, row_st = FALSE, estmethod = "ml"), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = Wp, row_st = FALSE, M = M, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = Wp, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = W, row_st = FALSE, estmethod = "ml"), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, W = Wp, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = Wp, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = W, row_st = FALSE, estmethod = "ml"), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, W = Wp, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("the model runs for connected sites (partition group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("the model runs for connected sites (random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  randcov_initial_val <- randcov_initial(group = 1, known = "group")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, randcov_initial = randcov_initial_val, row_st = FALSE), NA)

  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  randcov_initial_val <- randcov_initial(group = 1, known = "group")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, randcov_initial = randcov_initial_val, row_st = FALSE), NA)
  })
})

test_that("the model runs for connected sites (partition and random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)

  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("the model runs for unconnected sites", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "reml"), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "reml"), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "ml"), NA)
})

test_that("the model runs for unconnected sites (partition group)", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "reml"), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "reml"), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
})

test_that("the model runs for unconnected sites (random group)", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "reml"), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "reml"), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
})

test_that("the model runs for unconnected sites (partition and random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_type, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Upoly, spcov_initial = spcov_initial_val, random = ~group, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("the model runs for missing sites", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, row_st = FALSE, estmethod = "ml"), NA)
})

test_that("the model runs for missing sites (partition group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, partition_factor = ~group, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("the model runs for missing sites (random group)", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "ml"), NA)


  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_type, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  spcov_initial_val <- spcov_initial(spcov_type, de = 1, ie = 1, range = 0.1, known = "de")
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_Mpoly, spcov_initial = spcov_initial_val, random = ~group, row_st = FALSE, estmethod = "ml"), NA)
  })
})

test_that("examples run", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spmod <- spautor(y ~ x, exdata_poly, "car")
  expect_output(print(spmod))
  expect_error(summary(spmod), NA)
  expect_error(tidy(spmod), NA)
  # random effects
  spmod <- expect_error(spautor(y ~ x, exdata_poly, "car", random = ~group), NA)
  spmod <- expect_error(spautor(y ~ x, exdata_poly, "car", random = ~ (x | group) + (x | subgroup)), NA)
  # partition factor
  spmod <- expect_error(spautor(y ~ x, exdata_poly, "car", partition_factor = ~group), NA)
  # combining
  spmod <- expect_error(spautor(y ~ x, exdata_poly, "car", random = ~group, partition_factor = ~group), NA)
  # spcov_initial
  spcov_initial_val <- spcov_initial("car", range = 0.5, known = "range")
  spmod <- expect_error(spautor(y ~ x, exdata_poly, spcov_initial = spcov_initial_val), NA)
  # randcov_initial ("group" is shorthand for "1 | group")
  randcov_initial_val <- randcov_initial(1, nm = "group", known = "group")
  spmod <- expect_error(spautor(y ~ x, exdata_poly, "car", randcov_initial = randcov_initial_val), NA)
  })
})

test_that("errors occur", {
  W <- 1 * sf::st_intersects(exdata_poly, sparse = FALSE)
  diag(W) <- 0
  M <- seq_len(NROW(exdata_poly))
  expect_error(spautor(y ~ x, exdata_poly, "car", W = W, row_st = FALSE, M = M))
  expect_error(spautor(y ~ x, exdata_poly, "car", partition_factor = ~ group + subgroup))
  expect_error(suppressWarnings(spautor(y ~ as.factor(x) + group, exdata_poly, "car")))
  exdata_poly3 <- exdata_poly
  exdata_poly3$y <- as.character(exdata_poly3$y)
  expect_error(spautor(y ~ x, exdata_poly3, "car"))
  expect_error(spautor(as.character(y) ~ x, exdata_poly, "car"))
  exdata_poly3$y <- as.factor(exdata_poly3$y)
  expect_error(spautor(y ~ x, exdata_poly3, "car"))
  expect_error(spautor(as.factor(y) ~ x, exdata_poly, "car"))
  expect_error(spautor(y ~ x, exdata_poly, "xyz"))
  expect_error(spautor(y ~ x, exdata_poly, "exponential"))
  expect_error(spautor(y ~ x, exdata, "car"))
  expect_error(spautor(y ~ x, exdata_poly, "car", estmethod = "xyz"))
  exdata_poly4 <- exdata_poly
  exdata_poly4$x2 <- exdata_poly4$x
  expect_error(suppressWarnings(spautor(y ~ x + x2, exdata_poly4, "car")))
  exdata_poly4$x[1] <- NA
  expect_error(spautor(y ~ x, exdata_poly4, "car"))
})

test_that("additional covr", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  # spatial profiling
  spcov_initial_val <- spcov_initial("car", ie = 0.5) # just can't be zero and known
  expect_error(spautor(formula = y ~ x, data = exdata_poly, spcov_initial = spcov_initial_val), NA)

  # partition factor with one level and random effects
  exdata_poly$part <- as.factor(1)
  expect_error(spautor(formula = y ~ x, data = exdata_poly, "car", random = ~group, partition_factor = ~part), NA)
  exdata_Upoly$part <- as.factor(1)
  expect_error(spautor(formula = y ~ x, data = exdata_Upoly, "car", random = ~group, partition_factor = ~part), NA)
  exdata_Mpoly$part <- as.factor(1)
  expect_error(spautor(formula = y ~ x, data = exdata_Mpoly, "car", random = ~group, partition_factor = ~part), NA)
  })
})

test_that("messages occur", {
  expect_message(spautor(y ~ x, exdata_poly))
  spcov_initial_val <- spcov_initial("car")
  expect_message(spautor(y ~ x, exdata_poly, "car", spcov_initial = spcov_initial_val))
})

test_that("no variance error works", {
  exdata_poly$novar <- 1
  expect_error(spautor(novar ~ x, exdata_poly, "car"))
})

test_that("range negative works", {
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, range_positive = FALSE), NA)
  spcov_type <- "sar"
  expect_error(spautor(y ~ x, exdata_poly, spcov_type, range_positive = FALSE), NA)
})

test_that("emmeans works", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "car"
  spmod <- spautor(y ~ x * group, exdata_poly, spcov_type = spcov_type, estmethod = "reml")
  expect_equal(as.matrix(model.frame(delete.response(terms(spmod)), spmod$data[spmod$observed_index, , drop = FALSE])), as.matrix(emmeans::recover_data(spmod)))
  expect_error(emmeans::emmeans(spmod, ~ group, by = "x"), NA)
  })
})

test_that("emmeans works missing", {
  spcov_type <- "car"
  spmod <- spautor(y ~ x * group, exdata_Mpoly, spcov_type = spcov_type, estmethod = "reml")
  expect_equal(as.matrix(model.frame(delete.response(terms(spmod)), spmod$data[spmod$observed_index, , drop = FALSE])), as.matrix(emmeans::recover_data(spmod)))
  expect_error(emmeans::emmeans(spmod, ~ group, by = "x"), NA)
})

test_that("point distance works missing", {
  exdata_sf <- st_as_sf(exdata, coords = c("xcoord", "ycoord"), crs = NA)
  spcov_type <- "car"
  expect_error(spautor(y ~ x, exdata_sf, spcov_type = spcov_type, cutoff = 1), NA)
  expect_error(spautor(y ~ x, exdata_sf, spcov_type = spcov_type, cutoff = 1, row_st = FALSE), NA)
  expect_error(spautor(y ~ x, exdata_sf, spcov_type = spcov_type, cutoff = NULL)) # can't be NULL
  expect_error(spautor(y ~ x, exdata_sf, spcov_type = spcov_type, cutoff = 1e-8)) # too small of distance so no neighbors
})

test_that("covmatrix errors properly", {
  spcov_type <- "car"
  spmod <- spautor(y ~ x * group, exdata_Mpoly, spcov_type = spcov_type, estmethod = "reml")
  expect_error(covmatrix(spmod, newdata = NULL))
  expect_error(covmatrix(spmod, cov_type = "xyz"), NA) # when newdata not specified cov_type silently ignored
  expect_error(covmatrix(spmod, newdata = spmod$newdata, cov_type = "xyz"))
})

test_that("spcov_type none and ie work properly", {
  # a random effect (and, for some of these, partitioning/an unconnected-
  # sites correction) on top of this small fixture regularly leaves the
  # automatic n <= 500 Satterthwaite ddf computation's covariance-
  # parameter Hessian non-positive-definite -- spmodel already warns and
  # falls back to NULL ddf gracefully, so the warning is expected/
  # tolerated here
  suppressWarnings({
  spcov_type <- "none"
  spmod <- spautor(y ~ x * group, exdata_Mpoly, spcov_type = spcov_type, estmethod = "reml")
  expect_true(inherits(spmod, "splm"))
  spmod_lm <- splm(y ~ x * group, exdata_Mpoly, spcov_type = spcov_type, estmethod = "reml")
  expect_equal(spmod, spmod_lm)
  spcov_type <- "ie"
  spmod <- spautor(y ~ x * group, exdata_Upoly, spcov_type = spcov_type, estmethod = "reml")
  expect_true(inherits(spmod, "splm"))
  spmod_lm <- splm(y ~ x * group, exdata_Upoly, spcov_type = spcov_type, estmethod = "reml")
  expect_equal(spmod, spmod_lm)
  spmod <- spautor(y ~ x * group, exdata_poly, spcov_type = c("none", "ie", "car", "sar"), estmethod = "reml")
  expect_true(inherits(spmod, "spautor_list"))
  expect_true(inherits(spmod$none, "splm"))
  expect_true(inherits(coef(spmod$none, type = "spcov"), "none"))
  expect_true(inherits(spmod$ie, "splm"))
  expect_true(inherits(coef(spmod$ie, type = "spcov"), "ie"))
  expect_true(inherits(spmod$car, "spautor"))
  expect_true(inherits(coef(spmod$car, type = "spcov"), "car"))
  expect_true(inherits(spmod$sar, "spautor"))
  expect_true(inherits(coef(spmod$sar, type = "spcov"), "sar"))
  expect_error(glances(spmod), NA)
  })
})

test_that("optim non-convergence warning fires for spautor", {
  load(file = system.file("extdata", "exdata_poly.rda", package = "spmodel"))

  expect_warning(
    spautor(y ~ x, exdata_poly, spcov_type = "car", estmethod = "reml", control = list(maxit = 1)),
    "did not converge"
  )
  expect_warning(
    spautor(y ~ x, exdata_poly, spcov_type = "car", estmethod = "reml"),
    NA
  )
})

test_that("spautor() errors informatively when a formula/random/partition_factor variable is not in data", {
  load(file = system.file("extdata", "exdata_poly.rda", package = "spmodel"))

  # a same-named object in the calling environment (but not in data) should
  # not be silently picked up via ordinary formula scoping -- it should error
  not_a_col <- rnorm(NROW(exdata_poly))
  not_a_group <- factor(sample(letters[1:3], NROW(exdata_poly), replace = TRUE))

  expect_error(spautor(y ~ not_a_col, data = exdata_poly, spcov_type = "car"), "not_a_col.*not found in data")
  expect_error(spautor(not_a_col ~ x, data = exdata_poly, spcov_type = "car"), "not_a_col.*not found in data")
  expect_error(spautor(y ~ x, data = exdata_poly, spcov_type = "car", random = ~not_a_group), "not_a_group.*not found in data")
  expect_error(spautor(y ~ x, data = exdata_poly, spcov_type = "car", partition_factor = ~not_a_group), "not_a_group.*not found in data")

  # sanity: a valid call still works
  expect_s3_class(spautor(y ~ x, data = exdata_poly, spcov_type = "car"), "spautor")
})

test_that("spautor() formula supports . as shorthand for all predictors, excluding the sf geometry column", {
  load(file = system.file("extdata", "exdata_poly.rda", package = "spmodel"))
  d <- exdata_poly[, c("y", "x")] # sf's `[` keeps geometry regardless of selection

  mod_dot <- spautor(y ~ ., data = d, spcov_type = "car")
  mod_explicit <- spautor(y ~ x, data = d, spcov_type = "car")
  expect_equal(names(coef(mod_dot)), names(coef(mod_explicit)))
  expect_equal(unname(coef(mod_dot)), unname(coef(mod_explicit)))
  expect_false("geometry" %in% colnames(model.matrix(mod_dot)))

  expect_error(
    spautor(y ~ x, data = d, spcov_type = "car", partition_factor = ~.),
    "not supported in partition_factor"
  )
})

test_that("predict() only allows newdata = object$newdata for spautor()", {
  # spautor() prediction locations are fixed when the model is fit (they
  # determine the neighbor structure W/M used throughout fitting), so a
  # different newdata cannot be honored at predict() time -- previously it
  # was silently ignored (always predicting object$newdata regardless),
  # which risks the user believing their newdata was used
  load(file = system.file("extdata", "exdata_Mpoly.rda", package = "spmodel"))
  load(file = system.file("extdata", "exdata_poly.rda", package = "spmodel"))

  amod <- spautor(y ~ x, exdata_Mpoly, spcov_type = "car")

  expect_vector(predict(amod))
  expect_equal(predict(amod), predict(amod, newdata = amod$newdata))

  modified_newdata <- amod$newdata
  modified_newdata$x <- modified_newdata$x + 1
  expect_error(predict(amod, newdata = modified_newdata), "newdata cannot be specified")
  expect_error(predict(amod, newdata = exdata_poly), "newdata cannot be specified")

  # a model with no missing data at all should still error informatively
  amod_full <- spautor(y ~ x, exdata_poly, spcov_type = "car")
  expect_error(predict(amod_full), "No missing data to predict")

  # spautorRF()'s internal predict.spautor() call (with no explicit newdata,
  # relying on object$spautor$newdata) must still work
  skip_if_not_installed("ranger")
  sprfmod <- spautorRF(y ~ x, exdata_Mpoly, spcov_type = "car", num.trees = 100)
  expect_vector(predict(sprfmod))
})
