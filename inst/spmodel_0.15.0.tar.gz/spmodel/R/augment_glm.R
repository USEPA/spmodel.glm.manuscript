#' @param type.predict The scale (\code{response} or \code{link}) of fitted
#'   values and predictions obtained using \code{spglm()} or \code{spgautor} objects.
#' @param type.residuals The residual type (\code{deviance}, \code{pearson}, or \code{response})
#'   of fitted models from \code{spglm()} or \code{spgautor} objects. Ignored if
#'   \code{newdata} is specified.
#' @param newdata_size The \code{size} value for each observation in \code{newdata}
#'   used when predicting for the binomial family.
#' @param var_correct A logical indicating whether to return the corrected prediction
#'   variances when predicting via models fit using \code{spglm()} or \code{spgautor()}. The default is
#'   \code{TRUE}.
#' @rdname augment.spmodel
#' @method augment spglm
#' @order 3
#' @export
augment.spglm <- function(x, drop = TRUE, newdata = NULL, type.predict = c("link", "response"),
                          type.residuals = c("deviance", "pearson", "response"), se_fit = FALSE,
                          interval = c("none", "confidence", "prediction"), newdata_size,
                          level = 0.95, local = local, var_correct = TRUE, ...) {
  # a "type" argument (as used in spmodel <= v0.7.0) can't be deprecated with a
  # warning here, because "type" would ambiguously match both type.predict and
  # type.residuals via partial matching
  type.predict <- match.arg(type.predict)
  type.residuals <- match.arg(type.residuals)
  interval <- match.arg(interval)

  # a prediction interval needs an unobserved location; a confidence interval
  # around the fitted mean is still available below
  interval <- check_interval_augment(interval, !is.null(newdata))

  # set data and newdata
  # when newdata is NULL, augment the original fitted data with diagnostics;
  # otherwise augment new observations with predictions
  if (is.null(newdata)) {
    if (drop) {
      data <- cbind(model.frame(x), x$obdata[, c(x$xcoord, x$ycoord)])
    } else {
      data <- x$obdata
    }
  } else {
    data <- model.frame(x)
  }

  if (is.null(newdata)) {
    # GLM fitted values/diagnostics depend on scale (link vs response) and
    # residual type, unlike the Gaussian splm/spautor case
    augment_data <- tibble::tibble(.fitted = fitted(x, type = type.predict))
    if (se_fit || interval == "confidence") {
      # the interval is built on the link scale and then back-transformed, and
      # .se.fit stays on the link scale matching predict()
      se <- get_se_fitted_mean(x)
      if (interval == "confidence") {
        fitted_link <- fitted(x, type = "link")
        tstar <- qnorm(1 - (1 - level) / 2)
        lwr <- fitted_link - tstar * se
        upr <- fitted_link + tstar * se
        if (type.predict == "response") {
          lwr <- invlink(lwr, x$family, x$size)
          upr <- invlink(upr, x$family, x$size)
        }
        augment_data$.lower <- lwr
        augment_data$.upper <- upr
      }
      if (se_fit) augment_data$.se.fit <- se
    }
    tibble_out <- tibble::tibble(cbind(data, augment_data, influence(x, type = type.residuals)))
  } else {
    # newdata_size only matters for the binomial family (number of trials per
    # newdata row); NULL lets predict() fall back to its own default handling
    if (missing(newdata_size)) newdata_size <- NULL
    if (missing(local)) local <- NULL
    preds_newdata <- predict(x,
      newdata = newdata, type = type.predict, se.fit = se_fit, interval = interval,
      newdata_size = newdata_size, level = level, local = local, var_correct = var_correct
    )
    if (se_fit) {
      if (interval %in% c("confidence", "prediction")) {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata$fit[, "fit"]
        )
        augment_newdata$.lower <- preds_newdata$fit[, "lwr"]
        augment_newdata$.upper <- preds_newdata$fit[, "upr"]
      } else {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata$fit
        )
      }
      augment_newdata$.se.fit <- preds_newdata$se.fit
    } else {
      if (interval %in% c("confidence", "prediction")) {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata[, "fit"]
        )
        augment_newdata$.lower <- preds_newdata[, "lwr"]
        augment_newdata$.upper <- preds_newdata[, "upr"]
      } else {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata
        )
      }
    }

    # inheritance for sf or sp objects
    attr_sp <- attr(class(newdata), "package")
    if (!is.null(attr_sp) && length(attr_sp) == 1 && attr_sp == "sp") {
      stop("sf objects must be used instead of sp objects. To convert your sp object into an sf object, run sf::st_as_sf().", call. = FALSE)
    }

    if (inherits(newdata, "sf")) {
      # extract point coordinates from sf geometry (centroid handles
      # polygon/line geometries) so the model's xcoord/ycoord columns exist
      newdata <- suppressWarnings(sf::st_centroid(newdata))

      newdata <- sf_to_df(newdata)
      names(newdata)[[which(names(newdata) == ".xcoord")]] <-
        as.character(x$xcoord) # only relevant if newdata is sf data is not
      names(newdata)[[which(names(newdata) == ".ycoord")]] <-
        as.character(x$ycoord) # only relevant if newdata is sf data is not
    }

    tibble_out <- tibble::tibble(cbind(newdata, augment_newdata))
  }


  if (x$is_sf) {
    # sf installed
    # re-attach sf geometry to match the class of the original data
    if (inherits(newdata, "sf")) {
      tibble_out <- sf::st_as_sf(tibble_out,
        sf_column_name = x$sf_column_name,
        crs = x$crs
      )
    } else {
      tibble_out <- sf::st_as_sf(tibble_out,
        coords = c(x$xcoord, x$ycoord),
        crs = x$crs
      ) # may want to double check this for mismatching geometry names
      # i.e. geometry names that are not geometry
    }
    names(tibble_out)[names(tibble_out) == "geometry"] <- x$sf_column_name
    sf::st_geometry(tibble_out) <- x$sf_column_name
  }
  tibble_out
}

#' @rdname augment.spmodel
#' @method augment spgautor
#' @order 4
#' @export
augment.spgautor <- function(x, drop = TRUE, newdata = NULL, type.predict = c("link", "response"),
                             type.residuals = c("deviance", "pearson", "response"), se_fit = FALSE,
                             interval = c("none", "confidence", "prediction"), newdata_size,
                             level = 0.95, local, var_correct = TRUE, ...) {
  # a "type" argument (as used in spmodel <= v0.7.0) can't be deprecated with a
  # warning here, because "type" would ambiguously match both type.predict and
  # type.residuals via partial matching
  type.predict <- match.arg(type.predict)
  type.residuals <- match.arg(type.residuals)
  interval <- match.arg(interval)

  # se_fit and interval are prediction quantities that only exist at object$newdata
  if (is.null(newdata)) {
    newdata <- augment_areal_newdata(x, se_fit, interval)
  }

  # set data and newdata
  # spgautor fits on the full autocorrelation neighborhood (observed +
  # unobserved locations), so diagnostics are restricted to observed_index rows only
  if (is.null(newdata)) {
    if (drop) {
      if (x$is_sf) {
        data_sf <- x$data[x$observed_index, x$sf_column_name, drop = FALSE]
      }
      data <- model.frame(x)
    } else {
      data <- x$data[x$observed_index, , drop = FALSE]
    }
  }


  if (is.null(newdata)) {
    # newdata is NULL only when se and interval are not supplied
    augment_data <- tibble::tibble(.fitted = fitted(x, type = type.predict))
    if (x$is_sf && drop) {
      tibble_out <- tibble::tibble(cbind(data, augment_data, influence(x, type = type.residuals), data_sf))
    } else {
      tibble_out <- tibble::tibble(cbind(data, augment_data, influence(x, type = type.residuals)))
    }
  } else {
    if (missing(newdata_size)) newdata_size <- NULL
    if (missing(local)) local <- NULL
    preds_newdata <- predict(x,
      newdata = newdata, type = type.predict, se.fit = se_fit, interval = interval,
      newdata_size = newdata_size, level = level, local = local, var_correct = var_correct
    )
    if (se_fit) {
      if (interval %in% c("confidence", "prediction")) {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata$fit[, "fit"]
        )
        augment_newdata$.lower <- preds_newdata$fit[, "lwr"]
        augment_newdata$.upper <- preds_newdata$fit[, "upr"]
      } else {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata$fit
        )
      }
      augment_newdata$.se.fit <- preds_newdata$se.fit
    } else {
      if (interval %in% c("confidence", "prediction")) {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata[, "fit"]
        )
        augment_newdata$.lower <- preds_newdata[, "lwr"]
        augment_newdata$.upper <- preds_newdata[, "upr"]
      } else {
        augment_newdata <- tibble::tibble(
          .fitted = preds_newdata
        )
      }
    }
    tibble_out <- tibble::tibble(cbind(newdata, augment_newdata))
  }

  if (x$is_sf) {
    # sf installed
    tibble_out <- sf::st_as_sf(tibble_out,
      sf_column_name = x$sf_column_name,
      crs = x$crs
    )
    names(tibble_out)[names(tibble_out) == "geometry"] <- x$sf_column_name
    sf::st_geometry(tibble_out) <- x$sf_column_name
  }
  tibble_out
}
