#' @keywords internal
"_PACKAGE"

# package-level NAMESPACE directives: no code lives here, just the roxygen
# tags that generate import/export statements for all functions below
#' @import Matrix
#' @importFrom generics tidy glance augment
#' @importFrom graphics abline par points title
#' @importFrom parallel detectCores makeCluster parLapply stopCluster
#' @importFrom sf st_as_sf st_centroid st_coordinates st_crs st_drop_geometry st_geometry_type st_intersects st_is_longlat
#' @importFrom stats aggregate AIC anova BIC coef coefficients complete.cases confint cooks.distance cor
#'   dbeta dbinom dgamma dnbinom dpois
#'   delete.response deviance dist fitted fitted.values formula .getXlevels hatvalues
#'   influence kmeans lm logLik model.frame model.matrix model.offset model.response na.fail nobs na.omit na.pass pchisq pf
#'   pnorm predict printCoefmat pt qnorm qqnorm qqline qt quantile
#'   rbeta rbinom rgamma rnbinom rpois resid
#'   residuals reformulate rnorm rstandard terms uniroot var vcov
#' @importFrom tibble tibble as_tibble
NULL
