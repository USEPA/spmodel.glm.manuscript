#' @rdname confint.spmodel
#' @method confint spglm
#' @order 3
#' @export
confint.spglm <- confint.splm

#' @rdname confint.spmodel
#' @method confint spgautor
#' @order 4
#' @export
confint.spgautor <- confint.spautor
