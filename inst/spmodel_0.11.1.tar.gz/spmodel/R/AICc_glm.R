#' @method AICc spglm
#' @order 4
#' @export
AICc.spglm <- AICc.splm

#' @method AICc spgautor
#' @order 5
#' @export
AICc.spgautor <- AICc.spautor
