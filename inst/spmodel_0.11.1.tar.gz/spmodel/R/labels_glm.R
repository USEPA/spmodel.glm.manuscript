#' @rdname labels.spmodel
#' @method labels spglm
#' @order 3
#' @export
labels.spglm <- labels.splm

#' @rdname labels.spmodel
#' @method labels spgautor
#' @order 4
#' @export
labels.spgautor <- labels.spautor
