#' @rdname logLik.spmodel
#' @method logLik spglm
#' @order 3
#' @export
logLik.spglm <- logLik.splm

#' @rdname logLik.spmodel
#' @method logLik spgautor
#' @order 4
#' @export
logLik.spgautor <- logLik.spautor
