#' @rdname pseudoR2
#' @method pseudoR2 spglm
#' @order 4
#' @export
pseudoR2.spglm <- pseudoR2.splm

#' @rdname pseudoR2
#' @method pseudoR2 spgautor
#' @order 5
#' @export
pseudoR2.spgautor <- pseudoR2.spautor
