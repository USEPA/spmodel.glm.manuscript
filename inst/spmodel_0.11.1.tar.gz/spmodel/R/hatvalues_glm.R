#' @rdname hatvalues.spmodel
#' @method hatvalues spglm
#' @order 3
#' @export
hatvalues.spglm <- hatvalues.splm

#' @rdname hatvalues.spmodel
#' @method hatvalues spgautor
#' @order 4
#' @export
hatvalues.spgautor <- hatvalues.spautor
