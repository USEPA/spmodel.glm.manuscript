# #' @rdname BIC.spmodel
# #' @method BIC spglm
# #' @order 3
# #' @export
# BIC.spglm <- BIC.splm
#
# #' @rdname BIC.spmodel
# #' @method BIC spgautor
# #' @order 4
# #' @export
# BIC.spgautor <- BIC.spautor
