#' @rdname deviance.spmodel
#' @method deviance spglm
#' @order 3
#' @export
deviance.spglm <- deviance.splm

#' @rdname deviance.spmodel
#' @method deviance spgautor
#' @order 4
#' @export
deviance.spgautor <- deviance.spautor
