# #' @rdname AIC.spmodel
# #' @method AIC spglm
# #' @order 3
# #' @export
# AIC.spglm <- AIC.splm
#
# #' @rdname AIC.spmodel
# #' @method AICc spglm
# #' @order 8
# #' @export
# AICc.spglm <- AICc.splm
#
# #' @rdname AIC.spmodel
# #' @method AIC spgautor
# #' @order 4
# #' @export
# AIC.spgautor <- AIC.spautor
#
# #' @rdname AIC.spmodel
# #' @method AICc spgautor
# #' @order 9
# #' @export
# AICc.spgautor <- AICc.spautor
