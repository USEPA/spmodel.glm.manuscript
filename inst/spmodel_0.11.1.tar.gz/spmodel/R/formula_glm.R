#' @rdname formula.spmodel
#' @method formula spglm
#' @order 3
#' @export
formula.spglm <- formula.splm

#' @rdname formula.spmodel
#' @method formula spgautor
#' @order 4
#' @export
formula.spgautor <- formula.spautor
