#' @rdname glance.spmodel
#' @method glance spglm
#' @order 3
#' @export
glance.spglm <- glance.splm

#' @rdname glance.spmodel
#' @method glance spgautor
#' @order 4
#' @export
glance.spgautor <- glance.spautor
