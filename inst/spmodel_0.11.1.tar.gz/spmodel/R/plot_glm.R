#' @rdname plot.spmodel
#' @method plot spglm
#' @order 3
#' @export
plot.spglm <- plot.splm

#' @rdname plot.spmodel
#' @method plot spgautor
#' @order 4
#' @export
plot.spgautor <- plot.spautor
