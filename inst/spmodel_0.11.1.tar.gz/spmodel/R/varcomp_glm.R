#' @rdname varcomp
#' @method varcomp spglm
#' @order 4
#' @export
varcomp.spglm <- varcomp.splm

#' @rdname varcomp
#' @method varcomp spgautor
#' @order 5
#' @export
varcomp.spgautor <- varcomp.spautor
