library(testthat)
library(spmodel)

test_check("spmodel")
